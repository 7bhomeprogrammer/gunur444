const database = {
  kpop: [
    {
      title: "DDU-DU DDU-DU",
      info: "Один из самых популярных треков Blackpink, вышел в 2018.",
      image: "https://i.ytimg.com/vi/IHNzOHi8sJs/maxresdefault.jpg",
      video: "https://www.youtube.com/watch?v=IHNzOHi8sJs"
    },
    {
      title: "Kill This Love",
      info: "Гимн Blackpink о сильной любви и независимости.",
      image: "https://i.ytimg.com/vi/2S24-y0Ij3Y/maxresdefault.jpg",
      video: "https://www.youtube.com/watch?v=2S24-y0Ij3Y"
    }
  ],
  phonk: [
    {
      title: "DRIFT PHONK",
      info: "Стильная музыка для ночных заездов, часто без слов.",
      image: "https://i.ytimg.com/vi/0MIrKcLE92g/maxresdefault.jpg",
      video: "https://www.youtube.com/watch?v=0MIrKcLE92g"
    },
    {
      title: "Phonk House",
      info: "Смешение phonk и электронной клубной музыки.",
      image: "https://i.ytimg.com/vi/lkQaS4kTu7U/maxresdefault.jpg",
      video: "https://www.youtube.com/watch?v=lkQaS4kTu7U"
    }
  ]
};